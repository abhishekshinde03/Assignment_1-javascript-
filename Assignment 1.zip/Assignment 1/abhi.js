
//This is the function of the getorder which is called in the Submit button.
function getorder(){  
const Order ={
    //fetching the values from the form and defining it into the literal
    name:  document.getElementById("name").value,
    typeOfDrink:document.getElementById("type_of_drink").value,
    sizeOfCoffee:document.getElementById("size_of_coffee").value,
    Drizzle: document.getElementById("drizzle").value,
    whippedCream: document.getElementById("whipped_cream").value,
    Sweetener:document.getElementById("sweetener").value,
    coldFoam:document.getElementById("cold_foam").value,
    Dairy: document.getElementById("dairy").value,
     



/**MAIN CODING OF THE ASSIGNMENT */
/**order_details() is the method that will print the details of the customer coffee */
    order_details:function(){
        //Alert box
        alert('Thank you, '+Order.name+ ' you have selected '+Order.typeOfDrink+' The Size of Drink is '
        +Order.sizeOfCoffee+' Dairy '+Order. Dairy);
         /**It will call the coffee_order() method which will check the conditions that customer have added some changes to their coffee
         like Drizzle, whipped cream, sweetener and cold foam..*/
        Order.coffee_order();
       },

       //This method() is mainly made to check conditions of the add- ons added by customers.
       coffee_order:function(){  
           //Firstly, the drizzle is added condition is checked
           if(this.Drizzle == "yes")
            {
                  //Secondly, the whipped is added condition is checked
                if(this.whippedCream== "yes")
                    {
                     //Also, the Sweetener is added condition is checked
                        if(this.Sweetener== "yes")
                        {
                            //Lastly, the coldfoam condition is checked
                             if(this.coldFoam== "yes")
                                {
                                    alert('Hey, ' +Order.name + ' you have add- ons drizzle '+ Order.Drizzle+ ' whippedCream '+ Order.whippedCream+' sweetener '
                                    +Order.Sweetener+ ' cold foam '+Order.coldFoam);
               
                                }
                                //If the cold foam is not selected, it will jump to the else
                              else{
                                alert('Hey, ' +Order.name + ' you have add- ons drizzle '+ Order.Drizzle+ ' whippedCream '+ Order.whippedCream+' sweetener '
                                +Order.Sweetener+ ' cold foam '+Order.coldFoam);
                              }
                        }
                        //If the Sweetener is not selected, it will jump to the else
                        else{
                            alert('Hey, ' +Order.name + ' you have add- ons drizzle '+ Order.Drizzle+ ' whippedCream '+ Order.whippedCream+' sweetener '
                            +Order.Sweetener+ ' cold foam '+Order.coldFoam);
                        }
                    }
                    //If the whipped Cream is not selected, it will jump to the else
                    else{
                        alert('Hey, ' +Order.name + ' you have add- ons drizzle '+ Order.Drizzle+ ' whippedCream '+ Order.whippedCream+' sweetener '
                    +Order.Sweetener+ ' cold foam '+Order.coldFoam);
                    }
                }
                //If the Drizzle is not selected, it will jump to the else which means no add- ons are selected.
            else{
             alert(Order.name +"don't have any extra add- ons");
             } 
    },
       
        
}          
//Calling of the order_detials
Order.order_details();
};

